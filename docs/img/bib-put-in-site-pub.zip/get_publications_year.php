<?php
$_GET['bib']='Biblio-perso-globale-fr.bib';
$_GET['all']=1;
// $_GET['academic']=1;
include( 'bibtexbrowser.php' );
?>